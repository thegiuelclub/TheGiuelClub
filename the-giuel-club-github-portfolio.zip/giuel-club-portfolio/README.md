# The Giuel Club — Portfolio Website

A responsive, static portfolio website built with HTML, CSS and vanilla JavaScript. No build tools or dependencies are required.

## Preview locally

Open `index.html` in your browser. For the best local development experience, use the VS Code Live Server extension.

## Publish with GitHub Pages

1. Create a new GitHub repository (for example, `the-giuel-club`).
2. Upload **all files and folders** in this project to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish your site. Your URL will look like `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Personalize before publishing

- `index.html`: update your introduction, about text, services, project names, social links and email address.
- `style.css`: adjust colors in the `:root` variables at the top.
- `assets/`: replace the sample project artwork with your actual portfolio images. The four project panels are CSS-designed placeholders, not real client work.
- Replace the portrait placeholder in the About section with your own photo if desired.
- Update the social profile URLs and `mailto:` address in `index.html`.

## Brand palette

- Chocolate: `#322D29`
- Navy: `#222D52`
- Burgundy: `#72383D`
- Taupe: `#AC9C8D`
- Gray: `#D9D9D9`
- Cream: `#EFE9E1`

The site uses Google Fonts (Playfair Display and DM Sans); a system fallback is provided if fonts cannot load.
