# The Giuel Club — GitHub Pages Portfolio

A responsive, single-page portfolio website using The Giuel Club brand palette and logo.

## Files
- `index.html` — complete website (HTML, CSS, and JavaScript)
- `assets/giuel-club-logo.jpg` — cropped logo from your supplied brand image

## Customize before publishing
Open `index.html` and replace:
1. The About paragraph with your real introduction.
2. The four Project One–Four cards with your project titles and descriptions.
3. The timeline entries with your actual work and education history.
4. `your-email@example.com` and `@yourusername` with your contact details.

### Add project images
Put your images in the `assets` folder. For each project, replace the `<div class="placeholder-art">...</div>` inside its `.project-image` with:
`<img src="assets/your-project-image.jpg" alt="Description of your project">`

## Publish on GitHub Pages
1. Sign in to GitHub and create a **new public repository** (for example, `the-giuel-club`).
2. Upload `index.html` and the entire `assets` folder to the repository's root (not inside another folder).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub to publish. Your site will appear at `https://YOUR-USERNAME.github.io/the-giuel-club/`.

You can use the repository name `YOUR-USERNAME.github.io` instead if you want the site at the root of your GitHub Pages domain.
